
from django.shortcuts import render, redirect
from .models import Student


# Display all students
def student_list(request):
    students = Student.objects.all()
    return render(request, "index.html", {'students': students})


# Add a new student
def add_student(request):
    if request.method == "POST":

        student_id = request.POST['id']
        name = request.POST['name']
        dept = request.POST['dept']

        Student.objects.create(
            id=student_id,
            name=name,
            dept=dept
        )

        return redirect("student_list")

    return render(request, "add_student.html")


# Edit an existing student
def edit_student(request, id):

    student = Student.objects.get(id=id)

    if request.method == "POST":

        student.name = request.POST['name']
        student.dept = request.POST['dept']

        student.save()

        return redirect("student_list")

    return render(request, "edit_student.html", {'student': student})


# Delete a student
def delete_student(request, id):

    if request.method == "POST":

        student = Student.objects.get(id=id)
        student.delete()

    return redirect("student_list")
