
from django.db import models


class Student(models.Model):
    id = models.IntegerField(primary_key=True)
    name = models.CharField(max_length=100)
    dept = models.CharField(max_length=50)

    def __str__(self):
        return self.name
